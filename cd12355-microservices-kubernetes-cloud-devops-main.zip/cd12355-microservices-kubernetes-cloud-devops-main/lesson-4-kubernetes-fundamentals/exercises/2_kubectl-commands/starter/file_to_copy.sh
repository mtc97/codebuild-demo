#/bin/bash

echo "Hello! This should be run on the actual container"

df -h