1.
```bash
kubectl get deployment <DEPLOYMENT_NAME> -o yaml

2.
```bash
kubectl cp starter/file_to_copy.sh <POD_NAME>:/tmp
```

3.
```bash
kubectl delete pod <POD_NAME>
```