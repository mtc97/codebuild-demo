# Purpose of This Repo

The repo contains the starter code for exercises used in CD12355 **Microservices at Scale using AWS and Kubernetes** course. 