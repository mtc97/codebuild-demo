## Comparisons
* Build time: ~2 minutes --> ~10 seconds
* Image size: 823MB --> 111MB