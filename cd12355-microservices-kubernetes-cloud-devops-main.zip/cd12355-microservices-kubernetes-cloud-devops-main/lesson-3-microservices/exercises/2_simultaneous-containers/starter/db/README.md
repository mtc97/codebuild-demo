```bash
docker build --build-arg DB_PASSWORD=<DB_USERNAME> --build-arg DB_USERNAME=<DB_PASSWORD> .
```

```bash
docker run -p 5433:5432 <IMAGE_NAME>
```
